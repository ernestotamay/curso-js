//definicion de array: lista
var lista = [ ];

function agregar(){
    let elemento = document.getElementById("descripcionInput").value;
    lista.push(elemento);                

    imprimir();

}

function ordenar(){
    var tamanioArray = lista.length;
        for (let i=0; i < tamanioArray; i++){
            for (let j=i+1; j < tamanioArray; j++){   
                if (lista[i]>lista[j]){            
                    let aux = lista[j];
                    lista[j] = lista[i];
                    lista[i] = aux;
                }
            }
        }
    

    for (let i=0; i < lista.length; i++){
        document.getElementById("lista_ordenada").innerHTML += lista[i]+ "<br>";
    }

}


function imprimir(){
    for (let i=0; i < lista.length; i++){
        var cadenaElementos = lista[i]+ "<br>";
    }

    document.getElementById("elementosDeEntrada").innerHTML += cadenaElementos;
}