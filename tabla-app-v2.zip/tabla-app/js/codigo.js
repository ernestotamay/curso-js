var fila;
var numeroFila = 1;



function agregarFila(){
    
    fila = `<tr><td><input type="text" id="columnaCantidad${numeroFila}"></td><td><input type="text" id="columnaCodigo${numeroFila}"></td><td><input type="text" id="columnaDescripcion${numeroFila}"></td><td><input type="text" id="columnaPrecio${numeroFila}"></td><td><input type="text" id="columnaImporte${numeroFila}"></td></tr>`;

    document.getElementById("contenedor").innerHTML += fila;
    numeroFila++;
}

