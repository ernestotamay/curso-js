function leer(){
    var cantidad = document.getElementById("cantidadInput").value;
    var precio = document.getElementById("precioInput").value;


    //alert(`cantidad: ${cantidad}`+ " y " + `precio: ${precio}`);

    var importe = cantidad * precio;
    //alert(`cantidad: ${cantidad}`+ " x " + `precio: ${precio} = ${importe}`);
    document.getElementById("importeInput").value = importe;

    

}